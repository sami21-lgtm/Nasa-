# SpaceSkribble – NASA Sky Challenge

A multiplayer astronomy drawing and guessing game for school students (English + বাংলা).
Players log in, sketch planets, galaxies and nebulae, everyone else guesses, and every round ends with a NASA fact card.

## What is inside
- **Login first:** nobody reaches the game without an account (`login.html` → `register.html` → game). The server also rejects game sockets without a valid login.
- **Live NASA data** (home page, each card links to its source): APOD, NeoWs near-Earth asteroids, Exoplanet Archive.
- **NOVA AI tutor:** answers through the server using a real AI model, in English or Bangla. Falls back to a small demo if no key is set.
- **Bangla / English switch** on every page.
- **Multiplayer:** Socket.IO rooms, bots, scores, XP saved to the player's profile.
- Gravity Lab and cosmic distance ladder.

## Run it
```bash
npm install
cp .env.example .env     # optional locally; required in production
npm start                # http://localhost:3000
```
One server does everything (website, `/api/*`, NASA proxy, NOVA, multiplayer). No second terminal.

## Environment variables
| Name | Purpose |
|---|---|
| `JWT_SECRET` | 32+ random characters. Required when `NODE_ENV=production`. |
| `NASA_API_KEY` | Free key from api.nasa.gov. Defaults to `DEMO_KEY` (rate-limited). |
| `ANTHROPIC_API_KEY` | Turns on the real NOVA AI. Never put it in browser code. |
| `NOVA_MODEL` | Model name for NOVA (default `claude-sonnet-5-5`). |
| `DATABASE_PATH` | SQLite file location. Use a persistent disk on your host. |
| `CORS_ORIGINS` | Only if the website is on another domain than the server. |

## Deploy (recommended: Render)
1. Push this repo to GitHub (`.gitignore` already excludes `node_modules`, `.env` and the database).
2. On Render choose **New → Blueprint** and select the repo (`render.yaml` is included).
3. Add `NASA_API_KEY` and `ANTHROPIC_API_KEY` in the dashboard.
4. Add a persistent disk and set `DATABASE_PATH` to it, otherwise accounts reset on each deploy.

Netlify alone cannot run login, XP or multiplayer, because it only hosts static files.

## API
`POST /api/register` · `POST /api/login` · `GET /api/me` · `GET /api/progress` · `POST /api/forgot-password/*`
`GET /api/nasa/apod` · `/api/nasa/neo` · `/api/nasa/exoplanets` · `POST /api/nova`

## Add astronomy objects
Copy an entry in `public/data/spaceObjects.js` and change its fields (`id`, `name`, `aliases`, `category`, `difficulty`, `description`, `interestingFacts`, `observationGuide`, `stats`, `clues`, `images` with credits, `nasaReference`, `sketch`). Put images in `public/assets/img/`.

## Roadmap
- Classroom mode (teacher rooms and per-student reports)
- JPL Horizons "what can I see tonight from Dhaka"
- Offline / low-bandwidth mode
