/*
 * Login gate – load this FIRST (in <head>) on every page.
 *
 *  • Game / profile pages : no valid login  -> send to /login.html
 *  • Login / register page: already logged in -> send straight into the game
 *
 * It also exposes window.SS with small helpers used by the other scripts.
 */
(function () {
  'use strict';

  var KEY = 'spaceSkribbleUser';
  var BASE = (window.SS_API_BASE || '').replace(/\/$/, '');
  var file = location.pathname.split('/').pop().replace(/\.html$/, '');
  var isAuthPage = file === 'login' || file === 'register';

  function getUser() {
    try {
      var user = JSON.parse(localStorage.getItem(KEY) || 'null');
      return user && typeof user.token === 'string' && user.token ? user : null;
    } catch (e) {
      return null;
    }
  }

  function setUser(user, token) {
    var saved = Object.assign({}, user, { token: token });
    localStorage.setItem(KEY, JSON.stringify(saved));
    return saved;
  }

  function clearUser() {
    try { localStorage.removeItem(KEY); sessionStorage.removeItem(KEY); } catch (e) {}
  }

  // Only allow redirects to pages on this site.
  function safeNext() {
    var next = new URLSearchParams(location.search).get('next') || '';
    return /^\/(?!\/)[\w\-./?=&%]*$/.test(next) && !/^\/(login|register)/.test(next) ? next : '/index.html';
  }

  function goLogin() {
    var here = location.pathname + location.search;
    var next = file === '' || file === 'index' ? '' : '?next=' + encodeURIComponent(here);
    location.replace('/login.html' + next);
  }

  function logout() {
    clearUser();
    location.replace('/login.html');
  }

  // fetch() helper that adds the base URL and the login token.
  function api(path, options) {
    options = options || {};
    var headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
    var user = getUser();
    if (user) headers.Authorization = 'Bearer ' + user.token;
    return fetch(BASE + path, Object.assign({}, options, { headers: headers }));
  }

  window.SS = { KEY: KEY, base: BASE, getUser: getUser, setUser: setUser, clearUser: clearUser,
                api: api, logout: logout, safeNext: safeNext };

  // Ask the server whether the saved token is still good.
  // Returns 'ok', 'expired' or 'offline' (server unreachable – do not lock the player out).
  function check() {
    return api('/api/me').then(function (res) {
      return res.status === 401 ? 'expired' : res.ok ? 'ok' : 'offline';
    }).catch(function () { return 'offline'; });
  }

  var user = getUser();

  if (isAuthPage) {
    if (user) check().then(function (state) {
      if (state === 'ok') location.replace(safeNext());
      else if (state === 'expired') clearUser();
    });
    return;
  }

  // Protected page
  if (!user) { goLogin(); return; }

  // Hide the page until the session is confirmed, so nobody sees the game "flash".
  var style = document.createElement('style');
  style.textContent = 'html{visibility:hidden}';
  document.head.appendChild(style);
  var reveal = function () { if (style.parentNode) style.parentNode.removeChild(style); };
  setTimeout(reveal, 4000); // safety net

  check().then(function (state) {
    if (state === 'expired') { clearUser(); goLogin(); }
    else reveal();
  });
})();
